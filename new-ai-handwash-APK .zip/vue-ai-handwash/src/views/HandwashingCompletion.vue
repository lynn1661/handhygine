<template>
  <div v-loading="loading" class="load">
    <div class="home">
      <select-locale></select-locale>
      <div class="home-title">Handwashing Completion</div>
      <div class="home-svg">
        <div class="home-svg-img">
          <img v-if="showImg === 'Novice'" src="/public/Novice.png" alt="" />
          <img v-if="showImg === 'Pro'" src="/public/Pro.png" alt="" />
          <img v-if="showImg === 'Master'" src="/public/Master.png" alt="" />
        </div>
      </div>
      <div class="home-content">
        <div style="display: flex; justify-content: space-around">
          <div class="starImg" v-for="(item, index) in list">
            <div class="home-content-star">
              <img v-if="item.Step" src="/public/fullstar.png" alt="" />
              <img v-if="!item.Step" src="/public/nullstar.png" alt="" />
            </div>
            <div class="title">Step {{ index + 1 }}</div>
          </div>
        </div>
        <div style="margin: 21px 11px 31px 31px">
          <div style="margin-bottom: 5px">
            <span style="color: rgb(0, 159, 198)">1.</span>
            <span style="font-weight: 600">Regular Reminders</span>
            <span class="setpTitle">
              : Set prompts for handwashing before meals, after the restroom,
              and when arriving home.</span
            >
          </div>
          <div style="margin-bottom: 5px">
            <span style="color: rgb(0, 159, 198)">2.</span>
            <span style="font-weight: 600">Thorough Washing</span>
            <span class="setpTitle">
              : Spend enough time on handwashing. Quick rinses don't effectively
              remove germs.</span
            >
          </div>
          <div style="margin-bottom: 5px">
            <span style="color: rgb(0, 159, 198)">3.</span>
            <span style="font-weight: 600">Nail Hygiene</span>
            <span class="setpTitle">
              : Clean under fingernails where germs often hide.</span
            >
          </div>
          <div style="margin-bottom: 5px">
            <span style="color: rgb(0, 159, 198)">4.</span>
            <span style="font-weight: 600">Technique Review</span>
            <span class="setpTitle">
              : Periodically check your handwashing method to cover all hand and
              wrist areas</span
            >
          </div>
        </div>
      </div>
      <div class="home-subContent">
        Thank you for using our app to enhance your handwashing technique! Your
        health and safety are of utmost importance to us.
      </div>
      <div class="home-btn">
        <el-button @click="back">Home Page</el-button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from "vue";
import { useI18n } from "vue-i18n";
import SelectLocale from "@/components/SelectLocale.vue";
import { useRouter } from "vue-router";
import { useStore } from "vuex";
const store = useStore();
const router = useRouter();
const loading = ref(true);
const t = useI18n();
const HandwashingType = ref();
const back = () => {
  localStorage.removeItem("studnetID");
  sessionStorage.removeItem("studnetID");
  router.push({
    path: "/",
  });
};
const studnetId = computed(() => {
  return store.state.user.userID;
});
const list = ref();
const showImg = ref("");
onMounted(async () => {
  setTimeout(() => {
    loading.value = false; // 两秒后将loading状态设置为false，显示内容
  }, 2000);
  const res = await store.dispatch("user/rank", {
    id: studnetId.value,
  });
  HandwashingType.value = res?.rank;
  list.value = res?.step_correctness;
  const trueCount = list.value.reduce(
    (count, step) => count + (step.Step ? 1 : 0),
    0
  );
  if (trueCount >= 0 || trueCount <= 3) {
    showImg.value = "Novice";
  } else if (trueCount >= 4 || trueCount <= 6) {
    showImg.value = "Pro";
  } else if (trueCount === 7) {
    showImg.value = "Master";
  }
});
</script>
<style lang="scss" scoped>
@import "@/styles/main.scss";
.load {
  height: 100vh;
}
.home {
  &-title {
    text-align: center;
    height: 101px;
    line-height: 20px;
    color: rgba(55, 65, 81, 1);
    font-size: 72px;
    margin-top: 36px;
    @include devices(tablet) {
      height: 50px;
      line-height: 50px;
      font-size: 36px;
    }
    @include devices(air) {
      height: 50px;
      line-height: 50px;
      font-size: 36px;
    }
  }
  &-svg {
    margin: 0 auto;
    &-img {
      display: flex;
      justify-content: center;
      align-items: center;
      flex-direction: column;
      img {
        width: 479px;
        height: 479px;
        border-radius: 50%;
        @include devices(tablet) {
          width: 300px;
          height: 300px;
        }
        @include devices(air) {
          width: 300px;
          height: 300px;
        }
      }
    }
  }
  &-content {
    border-radius: 33px;
    background-color: rgba(191, 191, 61, 0.19);
    margin-left: 11px;
    margin-right: 14px;
    color: rgba(0, 0, 0, 1);
    font-size: 36px;
    @include devices(air) {
      font-size: 22px;
    }
    @include devices(tablet) {
      font-size: 22px;
    }
    .starImg {
      margin-left: 31px;
      width: 118px;
      height: 118px;
      @include devices(air) {
        width: 80px;
        height: 80px;
      }
      @include devices(tablet) {
        width: 80px;
        height: 80px;
      }
      .home-content-star {
        width: 89px;
        height: 89px;
        @include devices(air) {
          width: 60px;
          height: 60px;
        }
        @include devices(tablet) {
          width: 60px;
          height: 60px;
        }
        img {
          @include devices(air) {
            width: 60px;
            height: 60px;
          }
          @include devices(tablet) {
            width: 60px;
            height: 60px;
          }
        }
      }
      .title {
        color: rgba(33, 84, 118, 1);
        font-size: 25px;
      }
    }
  }
  &-subContent {
    height: 115px;
    color: rgba(33, 84, 118, 1);
    font-size: 26px;
    margin-left: 42px;
    margin-right: 25px;
    line-height: 31px;
    @include devices(tablet) {
      height: 80px;
      font-size: 22px;
    }
  }
  &-btn {
    text-align: center;
    margin-top: 11px;
    :deep(.el-button) {
      width: 358px;
      height: 102px;
      border-radius: 13px;
      background-color: rgba(147, 210, 243, 1);
      color: rgba(255, 255, 255, 1);
      font-size: 48px;
    }
  }
}
.setpTitle {
  font-size: 32px;
  @include devices(air) {
    font-size: 22px;
  }
  @include devices(tablet) {
    font-size: 22px;
  }
}
</style>
